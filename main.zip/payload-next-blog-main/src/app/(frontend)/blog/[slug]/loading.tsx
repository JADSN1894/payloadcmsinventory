export default function BlogPostPageLoading() {
    return <p>Loading...</p>
}
