export const MAX_SUMMARY_LENGTH = 160

export const STATUS_OPTIONS = {
    DRAFT: 'Draft',
    PUBLISHED: 'Published',
} as const

export const CACHE_TAG_ARTICLES = 'articles'
