export const ARTICLE_AUTHOR_ROLE_OPTIONS = {
    STAFF_WRITER: 'Staff Writer',
    GUEST_WRITER: 'Guest Writer',
    FLO_RIDA: 'Flo Rida',
    CONTRIBUTOR: 'Contributor',
    EDITOR: 'Editor',
} as const
